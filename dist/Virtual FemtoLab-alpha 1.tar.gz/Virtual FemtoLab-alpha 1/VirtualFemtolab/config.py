

NT         = 512
deltaT     = 128e-15
lambdaZero = 800e-9
        
          
